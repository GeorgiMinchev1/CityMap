#include <iostream>
#include <vector>
#include <string>
#include <utility>

//#include "doctest.h";
#include "city.h"
#include "intersection.h"
#include "intersectionbuilder.h"
/*
TEST_CASE("Intersection construction tests") {
    SUBCASE("Constructs an Intersection with given name") {
        Intersection ndk("NDK");
    }

    SUBCASE("Constructs an Intersection with given name and neighbours") {
        Intersection ndk("NDK Popa 150 5Kiosheta 800");
    }
}

TEST_CASE("Intersection validity tests") {
    SUBCASE("Intersection does not let neighbour with the same name be built") {
        Intersection ndk("NDK NDK 150");
    }

    SUBCASE("Intersection does not let two neighbours with the same name be built") {
        Intersection ndk("NDK 5Kiosheta 800 Popa 400 5Kiosheta 450");
    }

}

TEST_CASE("Map add function tests") {
    SUBCASE("An Intersection can be added in Map") {
        Intersection ndk("NDK Popa 150 5Kiosheta 800");
        Map map;
        map.addIntersection(&ndk);
    }

    SUBCASE("Many Intersections can be added in Map") {
        Intersection ndk("NDK Popa 150 5Kiosheta 800");
        Intersection kiosheta("5Kiosheta Popa 400 NDK 450");
        Map map;
        map.addIntersection(&kiosheta);
        map.addIntersection(&ndk);
    }

    SUBCASE("Cannot add one intersection more than once") {
        Intersection ndk("NDK Popa 150 5Kiosheta 800");
        Map map;
        map.addIntersection(&ndk);
        map.addIntersection(&ndk);
    }

    SUBCASE("Test of uniqueness in Map") {
        Map map;
        bool match = false;
        for (std::vector<Intersection*>::iterator it = map.begin(); it != map.end(); it++) {
            for (std::vector<Intersection*>::iterator it1 = map.next(it); it1 != map.end(); map.next(it1)) {
                if (it == it1)match = true;//todo: *it == *it1 -> operator *
            }
        }
        CHECK(match);
    }
}


TEST_CASE("Tests of funtion 1") {

}

TEST_CASE("Tests of funtion 2") {

}

TEST_CASE("Tests of funtion 3") {

}

TEST_CASE("Tests of funtion 4") {

}

TEST_CASE("Tests of funtion 5") {

}

TEST_CASE("Tests of funtion 6") {

}

TEST_CASE("Tests of funtion 7") {

}

// CityMap.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
*/

void uniquenessTest(City map) {
    bool match = false;
    using iterator = City::iterator;
    for (iterator it = map.begin(); it != map.end(); ++it) {
        iterator temp = it;
        iterator it1 = ++temp;
        while (it1 != map.end()) {
            if ((*it) == (*it1))match = true;
            ++it1;
        }
    }
    std::cout << !match << std::endl;
}

void function1Tests() {

}

void function2Tests() {

}

void function3Tests() {

}

void function4Tests() {

}

void function5Tests() {

}

void function6Tests() {

}

void function7Tests() {

}

int main()
{
    std::cout << "For every test 1/true is passed, 0/false is failed" << std::endl;
    std::cout << "Constructs an Intersection with given name" << std::endl;
    City city;
    std::cout << "city made" << std::endl;
    Intersection *ndk = city.buildIntersection("NDK");
    ndk->print();
    std::cout << std::endl;

    std::cout << "Constructs an Intersection with given name and neighbours" << std::endl;
    Intersection *ndk1 = city.buildIntersection("NDK Popa 150 5Kiosheta 800");
    ndk1->print();
    std::cout << std::endl;

    std::cout << "Intersection does not let neighbour with the same name be built" << std::endl;
    Intersection *ndk2 = city.buildIntersection("NDK NDK 150");
    if (ndk2 == nullptr)std::cout << 1 << std::endl << std::endl;
    else std::cout << 0 << std::endl << std::endl;

    std::cout << "Intersection does not let two neighbours with the same name be built" << std::endl;
    Intersection *popa1 = city.buildIntersection("Popa 5Kiosheta 800 NDK 400 5Kiosheta 450");
    if (popa1 == nullptr)std::cout << 1 << std::endl << std::endl;
    else std::cout << 0 << std::endl << std::endl;

    std::cout << "An Intersection can be added in Map\n" << std::endl;
    Intersection *popa2 = city.buildIntersection("Popa NDK 150 5Kiosheta 800");
    
    std::cout<< "Many Intersections can be added in Map\n" <<std::endl;
    Intersection *kiosheta = city.buildIntersection("5Kiosheta Popa 400 NDK 450");

    city.print();

    //std::cout<< "Cannot add one intersection more than once" <<std::endl;
    
    std::cout<< "Test of uniqueness in Map" <<std::endl;
    uniquenessTest(city);
    std::cout << std::endl;

    std::cout<< "Tests of funtion 1\n" <<std::endl;

    std::cout<< "Tests of funtion 2\n" <<std::endl;

    std::cout<< "Tests of funtion 3\n" <<std::endl;
    
    std::cout<< "Tests of funtion 4\n" <<std::endl;
    
    std::cout<< "Tests of funtion 5\n" <<std::endl;
    
    std::cout<< "Tests of funtion 6\n" <<std::endl;
    
    std::cout<< "Tests of funtion 7\n" <<std::endl;
    
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
