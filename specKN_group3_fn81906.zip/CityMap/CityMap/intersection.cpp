#include "intersection.h"
#include <iostream>

Intersection::Intersection() {
	name = std::string();
	isClosed = false;
	visited = false;
	neighbours = std::vector <std::pair<Intersection*, int>>();
}

Intersection::Intersection(std::string _name) {
	name = _name;
	isClosed = false;
	visited = false;
	neighbours = std::vector <std::pair<Intersection*, int>>();
}

Intersection::Intersection(Intersection const& inter) {
	name = inter.name;
	isClosed = inter.isClosed;
	visited = false;
	neighbours = inter.neighbours;
}

Intersection& Intersection::operator =(Intersection const& inter) {
	name = inter.name;
	isClosed = inter.isClosed;
	neighbours = inter.neighbours;
	visited = false;
	return *this;
}

void Intersection::addNeighbour(Intersection* neigh, int distance) {
	neighbours.push_back(std::make_pair(neigh, distance));
}

void Intersection::addIncomingNeighbour(Intersection* inter) {
	incomingNeighbours.push_back(inter);
}

int Intersection::neighbourCount() {
	return neighbours.size();
}

int Intersection::incomingNeighbourCount() {
	return incomingNeighbours.size();
}

void Intersection::print() {
	std::cout << name ;
	for (int i = 0; i < neighbours.size(); i++) {
		//std::string neighName = neighbours;//;[i].first()->getName();
		Intersection* neigh = neighbours[i].first;
		std::cout << " " << neigh->getName() << " "<<neighbours[i].second;
	}
	std::cout << std::endl;
}

bool Intersection::isMarked() {
	return visited;
}

void Intersection::mark() {
	visited = true;
}

Intersection::~Intersection() {
	using iterator = std::vector<std::pair<Intersection*, int>>::iterator;
	for (iterator it = neighbours.begin(); it != neighbours.end(); ++it) {
		neighbours.erase(it);
	}
	neighbours.clear();

	using iterator1 = std::vector<Intersection*>::iterator;
	for (iterator1 it = incomingNeighbours.begin(); it != incomingNeighbours.end(); ++it) {
		incomingNeighbours.erase(it);
	}
	incomingNeighbours.clear();
}