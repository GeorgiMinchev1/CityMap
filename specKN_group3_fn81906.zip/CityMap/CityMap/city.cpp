#include<iostream>
#include<sstream>

#include "intersection.h"
#include "city.h"

bool City::isUnique(std::string name) {
	Intersection* inter = getIntersection(name);
	if (inter == nullptr)return true;
	return false;
}

bool City::addIntersection(Intersection* inter) {
	if (inter != nullptr && isUnique(inter->getName())) {
		map.push_back(inter);
		return true;
	}
	return false;
}

bool isInVector(std::vector<std::string> list, std::string str, int index) {
	for (int i = 0; i < list.size(); i++)if (str.compare(list[i]) == 0 && i != index)return true;
	return false;
}

Intersection* City::getIntersection(std::string name) {
	using vectorIterator = std::vector<Intersection*>::iterator;
	for (iterator it = map.begin(); it != map.end(); ++it) {
		if (name.compare((*it)->getName()) == 0)return *it;
	}
	/*Intersection* newIntersec = new Intersection(name);
	this->addIntersection(newIntersec);
	return newIntersec;*/
	return nullptr;
}

Intersection* City::buildIntersection(std::string expression) {
	
	//unzipping expression 
	std::vector<std::string> strings;
	int index = 0;
	int nextIndex = expression.find_first_of(" ", index + 1);
	while (nextIndex != std::string::npos) {
		strings.push_back(expression.substr(index, nextIndex - index));
		index = nextIndex + 1;
		nextIndex = expression.find_first_of(" ", index + 1);
	}
	strings.push_back(expression.substr(index, expression.length()));
	//assigning intersection name
	Intersection *intersection = getIntersection(strings[0]);
	if (intersection == nullptr) {
		intersection = new Intersection(strings[0]);
		addIntersection(intersection);
	}
	if (intersection->neighbourCount() > 0 && strings.size() > 1)return nullptr;

	for (int i = 1; i < strings.size(); i += 2) {
		if (strings[i].compare(strings[0]) == 0) return nullptr;
		if (isInVector(strings, strings[i], i))return nullptr;
		//checking if the neighbour has the same name as the intersection
		Intersection* inters1 = getIntersection(strings[i]);
		std::stringstream stream(strings[i + 1]);
		int distance;
		stream >> distance;
		if (inters1 == nullptr) {
			//defining the neighbour
			inters1 = new Intersection(strings[i]);
			map.push_back(inters1);
			//this->addIntersection(inters1);
			//inters1 = strings[i];
			//using stringstream to make the string -> integer

			//adding neighbour
		}

		intersection->addNeighbour(inters1, distance);
		inters1->addIncomingNeighbour(intersection);
	}
	return intersection;
	
}

void City::print() {
	std::cout << "Printing city: " << std::endl;
	for (int i = 0; i < map.size(); i++) {
		std::cout <<i + 1<< ". intersection is" << std::endl;
		map[i]->print();
		std::cout << "Incoming neighbour count = " << map[i]->incomingNeighbourCount() << std::endl;
	}
	std::cout << std::endl;
}

City::~City() {
	using iterator = std::vector<Intersection*>::iterator;
	iterator it = map.begin();
	it = map.erase(it);
	for (it; it != map.end(); ++it) {
		it = map.erase(it);
	}
	map.clear();
}