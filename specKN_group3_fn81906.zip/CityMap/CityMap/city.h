#ifndef __CITYMAP_H
#define __CITYMAP_H
#include<vector>
#include <string>
#include "intersection.h"


class City {
	std::vector<Intersection*> map;
	/*class iterator : std::vector<Intersection*>::iterator {

	};
	*/
public:
	City() {
		//using iterator = std::vector<Intersection*>::iterator;
		iterator begin = map.begin();
		iterator end = map.end();
	}

	bool addIntersection(Intersection* inter);
	using iterator = std::vector<Intersection*>::iterator;
	
	iterator begin() {
		return map.begin();
	}
	// = map.begin();
	iterator end() {
		return map.end();
	}// = map.end();
	/*iterator next(iterator it) {
		return it++;
	}*/

	iterator getNormalIterator();
	
	bool isUnique(std::string name);

	Intersection* buildIntersection(std::string expression);//ако има такова кръстовище се вика функцията за адване на съседи
	Intersection* getIntersection(std::string name);

	void print();

	bool hasPathBetween(Intersection const& inter1, Intersection const& inter2);
	void showTheShortestPaths(Intersection const& inter1, Intersection const& inter2, bool considerClosed);
	bool hasSmallTour(Intersection const& inter);
	bool hasTourToAllIntersections();
	bool canGoToAllIntersections(Intersection const& inter);
	void showDeadEnds();

	~City();
};

#endif